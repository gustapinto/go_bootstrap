package main

import (
	"app/config"
	"app/route"

	"github.com/gin-gonic/gin"
)

func main() {
	// Create the gin engine
	engine := gin.Default()

	// Register the routes
	route.RegisterRoutes(engine, []route.Route{
		route.NewApiRoutes(),
	})

	// Start the gin engine
	if err := engine.Run(config.ServerAddr()); err != nil {
		panic(err)
	}
}
