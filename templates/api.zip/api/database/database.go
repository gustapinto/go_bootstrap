package database

import (
	"app/config"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var db *gorm.DB

// DB creates a new database connection if it doenst already exists, acting as
// a singleton
func DB() (*gorm.DB, error) {
	if db != nil {
		return db, nil
	}

	newDb, err := gorm.Open(postgres.Open(config.PostgresDsn()), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		return nil, err
	}

	db = newDb

	return db, nil
}
