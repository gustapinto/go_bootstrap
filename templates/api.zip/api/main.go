package main

import (
	"app/config"
	"app/database"
	"app/route"

	"github.com/gin-gonic/gin"
)

func main() {
	routes := []route.Route{
		route.NewApiRoutes(),
	}
	models := []any{}

	bootstrap(routes, models)
}

// bootstrap connects to a database, starts the webserver and run the model
// migrations
func bootstrap(routes []route.Route, models []any) {
	// Open the database connection and execute the migrations
	db, err := database.DB()
	if err != nil {
		panic(err)
	}

	if err := db.AutoMigrate(models...); err != nil {
		panic(err)
	}

	// Create the gin engine
	engine := gin.Default()

	// Register the routes
	route.RegisterRoutes(engine, routes)

	// Start the gin engine
	if err := engine.Run(config.ServerAddr()); err != nil {
		panic(err)
	}
}
