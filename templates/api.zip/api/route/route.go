package route

import (
	"github.com/gin-gonic/gin"
)

// Route is the interface for structs who register routes
type Route interface {
	Register(*gin.Engine)
}

// RegisterRoutes register the passed routes defined in the Route.Register(*gin.Engine)
// method
func RegisterRoutes(router *gin.Engine, routes []Route) {
	for _, route := range routes {
		route.Register(router)
	}
}
