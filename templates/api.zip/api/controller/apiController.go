package controller

import "github.com/gin-gonic/gin"

type ApiController struct{}

func NewApiController() *ApiController {
	return &ApiController{}
}

func (ac *ApiController) HelloWorld(c *gin.Context) {
	if _, err := c.Writer.WriteString("Hello World!"); err != nil {
		panic(err)
	}
}
