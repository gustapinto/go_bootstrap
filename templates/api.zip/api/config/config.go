package config

import (
	"os"
)

// ServerAddr build a http address using environment variables
func ServerAddr() string {
	return os.Getenv("SERVER_HOST") + ":" + os.Getenv("SERVER_PORT")
}

// PostgresDsn build a PostgreSQL compatible DSN using environment variables
func PostgresDsn() string {
	return "host=" + os.Getenv("POSTGRES_HOST") +
		" user=" + os.Getenv("POSTGRES_USER") +
		" password=" + os.Getenv("POSTGRES_PASSWORD") +
		" dbname=" + os.Getenv("POSTGRES_DB") +
		" port=" + os.Getenv("POSTGRES_PORT")
}
