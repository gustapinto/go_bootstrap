package route

import (
	"app/controller"

	"github.com/gin-gonic/gin"
)

type ApiRoutes struct {
	apiController *controller.ApiController
}

func NewApiRoutes() *ApiRoutes {
	return &ApiRoutes{
		apiController: controller.NewApiController(),
	}
}

func (ar *ApiRoutes) Register(router *gin.Engine) {
	router.GET("/api", ar.apiController.HelloWorld)
}
